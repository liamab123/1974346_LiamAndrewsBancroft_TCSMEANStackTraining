const { readAndLog } = require("./logging");

readAndLog();