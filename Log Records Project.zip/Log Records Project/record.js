class Record{
    constructor(fName,lName,gender,email,dC){
        this.fName = fName;
        this.lName = lName;
        this.gender = gender;
        this.email = email;
        this.dC = dC;
    }
}
exports.Record = Record;