export class Contact{
    constructor(public name:string,public phoneNumber:string){}
}