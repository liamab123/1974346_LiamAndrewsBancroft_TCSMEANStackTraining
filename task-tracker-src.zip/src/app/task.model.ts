export class Task{
    constructor(
        public ID:string,
        public name:string,
        public task:string,
        public date:string
    ){
        

    }
}