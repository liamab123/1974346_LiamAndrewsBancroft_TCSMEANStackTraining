export class Option{
    constructor(
        public option:string,
        public isAnswer:boolean,
        public selected:boolean = false
    ){
        

    }
}